from bs4 import BeautifulSoup as bs

file = 'port.xml'
with open (file) as f:
    d=f.read()

ad = bs(d, "xml")
n=1
  
for index in ad.find_all("portfolio"):

    I=f'<p><a href="ensaio1.html" title="de Helena Faria" target="_blank">THE GENDER ISSUE IN THE ADVERTISMENT</a></p>' 
    I+=f'<p><a href="ensaio2.html" title="de Helena Faria" target="_blank">“THE BOOK THIEF” </a></p>'
    I="<h1><center>PORTFOLIO DE ENSAIOS</center></h1>" + I 
    I+=f'<hr><center><b>REALIZADO POR:</b></hr>' 
    I+=f'<p>{index.parent.author}</p>' 
    I+=f'<p>{index.parent.author_n}</p>'
    I+=f'<p>{index.parent.email}</center></p>'
    I+=f'<hr>{index.parent.descr}</p>'

    I=f'<img src="ILCH-pt.jpg" title="Logo ILCH" width="200" height="150" style="float:center">' + I

with open(f'index.html', 'w') as f:
    f.write(I)


for ensaio in ad.find_all("essay1"):

    E=f'<p><center><b>{ensaio.parent.title_e}</b></center></p>'
    E+=f'<hr>{ensaio.parent.curricular_unit}</p>'
    E+=f'<p>{ensaio.parent.degree}</p>'
    E+=f'<p>{ensaio.parent.author}<hr>'
    E+=f'<hr>{ensaio.parent.link}</p>'
    E+=f'<p><center>{ensaio.parent.introduction}</p>'
    E+=f'<p>{ensaio.parent.body}</p>'
    E+=f'<p>{ensaio.parent.conclusion}</center></p>'

    E=f'<img src="ILCH-pt.jpg" title="Logo ILCH" width="150" height="100" style="float:center">' + E

    with open(f'ensaio{1}.html', 'w') as f:
        f.write(E)

    n+=1
    
for ensaio in ad.find_all("essay2"):

    H=f'<p><center><b>{ensaio.parent.title_e}</b></center></p>'
    H+=f'<hr>{ensaio.parent.curricular_unit}</p>'
    H+=f'<p>{ensaio.parent.degree}</p>'
    H+=f'<p>{ensaio.author}<hr>'
    H+=f'<hr>{ensaio.parent.link2}</p>'
    H+=f'<p><center>{ensaio.parent.introduction}</center></p>'
    H+=f'<p>{ensaio.parent.body}</center></p>'


    H=f'<img src="ILCH-pt.jpg" title="Logo ILCH" width="150" height="100" style="float:center">' + H

    with open(f'ensaio{2}.html', 'w') as f:
        f.write(H)

    n+=1


