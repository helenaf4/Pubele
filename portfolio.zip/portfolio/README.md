# Portfolio de ensaios Publicação Eletrónica

1. abrir e ler o file 'port.xml'

2. No index, encontrar a tag 'portfolio' e, dentro dessa,  encontrar as tags 'author', 'author_n', 'email' e 'descr' de forma a criar um indice com link para os ensaios, quem o fez e uma pequena descrição do que é que consiste o trabalho realizado. 

3. Para cada ensaio foi criado uma página html independente onde se extrai as etiquetas 'title_e', 'curricular_unit', 'degree', 'author', 'introduction', 'body', 'conclusion'. Extrai-se também o link direcionado para cada ensaio guardado em pdf. 

    n=1 e n+=1 permite ao comando correr mais do que um ensaio.