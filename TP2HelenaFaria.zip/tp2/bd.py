import shelve

ensaios = [
    {
        'id': 0,
        'title': 'The Gender Issue in Advertisment.',
        'conteudo': 'The aim of this essay is to show how the gender issues have always been present in the advertisement, and it will also be analysed some of those adds. Advertisement is an impersonal mediator function between the buyers and the sellers, not only to bring awareness of the existence of a certain product in the market, but also to sell, influencing the buyer emotionally. (Pereira, 1997:41, Abreu, M. & Sousa, J., Trad.) Since the beginning of time men have always been seen in the eyes of society as worthier than women, they were the providers, the role models, the ones who had rights and were able to have and opinion and make impartial decisions. On the other hand, women were always objectified, seen has too emotional and irrational to have an opinion or make a judgement, they were supposed to be the men’s property and live a submissive life where their only purpose was to serve their husband.   Sexism- Prejudice or discrimination based on sex or gender, especially against women and girls. Sexism can be a belief that one sex is superior to or more valuable than another sex. It imposes limits on what men and boys can and should do and what women and girls can and should do. The concept of sexism was originally formulated to raise consciousness about the oppression of girls and women, although by the early 21st century it had sometimes been expanded to include the oppression of any sex, including men and boys, intersexual people, and transgender people. Sexism in a society is most commonly applied against women and girls. It functions to maintain patriarchy, or male domination, through ideological and material practices of individuals, collectives, and institutions that oppress women and girls on the basis of sex or gender. Such oppression usually takes the forms of economic exploitation and social domination. Sexist behaviours, conditions, and attitudes perpetuate stereotypes of social (gender) roles based on one’s biological sex. A common form of socialization that is based in sexist concepts teaches particular narratives about traditional gender roles for males and females. According to such a view, women and men are opposite, with widely different and complementary roles: women are the weaker sex and less capable than men, especially in the realm of logic and rational reasoning. Women are relegated to the domestic realm of nurturance and emotions and, therefore, according to that reasoning cannot be good leaders in business, politics, and academia. Although women are seen as naturally fit for domestic work and are superb at being caretakers, their roles are devalued or not valued at all when compared with men’s work.'
    },
    {
        'id': 1,
        'title': 'The Book Thief.',
        'conteudo': 'In this essay, it will be presented an analysis of a book written by Marcus Zusak called “The book thief” and an analysis with the film that was made inspired by that book. After that, it will be made a comparison between the book and the film. The book thief is a 2005 historical novel written by the Australian author Marcus Zusak. By the time it was released it became an international bestseller and was translated into several languages. It was adapted into a 2013 feature film of the same name. The film was nominated for one Oscar, won 9 prizes such as Best Youth Performance (won in 2013), Best Film (won in 2014), U.S. Cinema (won in 2013) and got another 16 nominations.'
    },
    {
        'id': 2,
        'title': 'Liderança e Empreendedorismo.',
        'conteudo': 'Neste projeto, realizado no âmbito da Unidade Curricular Liderança e Empreendedorismo, foi-nos proposto a análise de uma empresa à nossa escolha. Desta forma, escolhemos a empresa têxtil portuguesa LMA, Leandro Manuel Araújo, S.A, a qual iremos estudar o modelo de negócio e a estratégia que esta tem vindo a desenvolver.A empresa têxtil LMA é caraterizada pelo seu espírito visionário, assim como qualidade e inovação são palavras que a descrevem. Foram estas características que permitiram que a empresa se afirmasse no mercado global. Assim sendo, ao longo do projeto será feito, inicialmente, uma breve apresentação da empresa eleita por nós, e por conseguinte serão analisados e estudados três canvas, sendo estes, Modelo de negócio, Proposta de valor e Análise estratégica.'
    },
    {
        'id': 3,
        'title': 'US President Donald Trump’s Speech to the United Nations General Assembly.',
        'conteudo': 'This essay will be focused on the 2018’s speech given by the United States President Donald Trump to the United Nations General Assembly. In this work it is intended to show how the speaker puts in practice some techniques helping the less focused hear to be aware of the common tactics used in the world of politics and also explain why the audience itself is not capable of detect. Even though his speeches are widely known as controversial, this essay will be aimed towards rhetoric, in other terms, it will be analyzed how the speaker uses techniques such as rhetorical figures, rhetorical appeals and rhetorical fallacies in order to deliver his message more affectively and persuade his audience.'
    },
    {
        'id': 4,
        'title': 'THE CULTURE OF THE GREAT GATSBY.',
        'conteudo': 'This work is about one of the most famous novels of the American literature, The Great Gatsby. The novel was written in 1925 by the American author Francis Scott Fitzgerald, as an amazing representation of the Roaring Twenties. “The Great Gatsby” can be considered by many, the book that is able to better represent the 20s, not only by the development of the society but also emphasizing he controversial side of the decade. It is by that amazing representation that this book will be used as guidance for the description of the culture of this period of time. In this, it will be given a small summary of the plot of the book, for the better contextualization of the reader, and later will be explain the actual culture of “The Great Gatsby”, and how the author was able to explore the themes that mainly marked that era such as the decadence and Prohibition.'
    }
]


autor = [
    'Helena Faria', 
    '22 anos',
    'pg39381',
    'Mestrado em Humanidades Digitais'
]



def find_all():
    with shelve.open('ensaios.db') as s:
        return list(s.keys())


def find_one(ensaio):
    with shelve.open('ensaios.db') as s:
        return { 'ensaios': ensaios, 'conteudo': s[conteudo] }


def insert(ensaio_data):
    with shelve.open('ensaios.db', writeback=True) as s:
        s[ensaio_data['ensaio']] = ensaio_data['conteudo']
        return list(s.keys())