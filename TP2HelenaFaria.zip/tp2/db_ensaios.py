import shelve


def find_all():
    with shelve.open('ensaios.db') as s:
        return list(s.keys())


def find_one(ensaio):
    with shelve.open('ensaios.db') as s:
        return { 'ensaios': ensaios, 'conteudo': s[ensaios] }


def insert(ensaio_data):
    with shelve.open('ensaios.db', writeback=True) as s:
        s[ensaio_data['ensaio']] = ensaio_data['conteudo']
        return list(s.keys())