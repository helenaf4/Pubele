from flask import Flask, render_template, request, redirect 
from re import *
import shelve
from bd import autor, ensaios
import requests

import json

import db_ensaios



app = Flask(__name__)




#cria o indice
@app.route('/')
def index():
    return render_template('index.html')



#cria uma pagina para o autor
@app.route('/autor')
def autorl():
    return render_template('autor_view.html', title='Autor', autor=autor)



#cria pagina ensaios
@app.route('/ensaios')
def ensaiosl():
    return render_template('ensaios_view.html', title='Ensaios', ensaios=ensaios)





#cria individual ensaios
@app.route('/ensaios/ensaio/<id_>')
def ensaiol(id_):
    return render_template('ensaio.html', p = ensaios[int(id_)])






@app.route('/ensaios', methods=['GET'])
def get_ensaios():
    res = requests.get('http://localhost:5000/api/ensaios')
    ps = json.loads(res.content)
    print(ps)

    return render_template('ensaios_view.html', ensaios=ps)




@app.route('/ensaios', methods=['POST'])
def post_ensaio():
    data = dict(request.form)
    print(data)
    requests.post('http://localhost:5000/api/ensaios', data=data)

   
    return redirect('http://localhost:5000/ensaios')






@app.route('/ensaios/<ensaio>', methods=['GET'])
def get_ensaio(ensaio):
    res = requests.get('http://localhost:5000/api/ensaios/' + ensaio)

    p = json.loads(res.content)
    return render_template('ensaios_view.html', p=p)





@app.route('/ensaios/<exp>')
def grep_p(exp):
    r = [ e for e in ensaios if search(exp, e)]
    return render_template('exp_search.html', title = rf'Ensaios que contenham {exp}' , ensaio=r)





#api
@app.route('/api/ensaios', methods=['GET'])
def api_get_ensaios():
   
    ps = db_ensaios.find_all()
    return json.dumps(ps)



@app.route('/api/ensaios', methods=['POST'])
def api_post_ensaio():
    
    data = dict(request.form)
    db_ensaios.insert(data)

    return json.dumps(db_ensaios.find_all())


@app.route('/api/ensaios/<ensaio>', methods=['GET'])
def api_get_ensaio(ensaio):
    p = db_ensaios.find_one(ensaio)
    return json.dumps(p)
